﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Comerciante
    {
        private string Apellido;
        private string Nombre;

        public Comerciante(string nombre,string apellido)
        {
            this.Apellido = apellido;
            this.Nombre = nombre;
        }

        public static implicit operator string(Comerciante a)
        {
            string datos = "";

            if(a.Nombre != "" && a.Apellido != "")
            {
                datos = " " + a.Nombre + " - " + a.Apellido;
            }

            return datos;
        }

        public static bool operator ==(Comerciante a, Comerciante b)
        {
            bool respuesta = false;
            if(a.Nombre == b.Nombre && a.Apellido == b.Apellido)
            {
                respuesta = true;
            }

            return respuesta;
        }

        public static bool operator !=(Comerciante a, Comerciante b)
        {
            return !(a == b);
        }
    }
}
