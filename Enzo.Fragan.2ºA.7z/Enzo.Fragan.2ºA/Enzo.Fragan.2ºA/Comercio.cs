﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Comercio 
    {
        protected int _cantidadDeEmpleados;
        protected Comerciante _comerciante;
        protected static Random _generadorDeEmpleados;
        protected string _nombre;
        protected float _precioAlquiler;

        public int CantidadDeEmpleados
        {
            get {
                _cantidadDeEmpleados = _generadorDeEmpleados.Next(1, 100);
                return _cantidadDeEmpleados; }
        }

        static Comercio()
        {
            Comercio._generadorDeEmpleados = new Random();
        }

        public Comercio(float precioAlquiler,string nombreComercio,string nombre,string apellido) : this(nombreComercio,new Comerciante(nombre,apellido),precioAlquiler)
        {
           
        }

        public Comercio(string nombre,Comerciante comerciante,float precioAlquiler) 
        {
            this._nombre = nombre;
            this._comerciante = comerciante;
            this._precioAlquiler = precioAlquiler;
        }

        public static explicit operator string(Comercio a)
        {
            return a.mostrar(a);
        }

        private string mostrar(Comercio c)
        {
            return c._nombre + " " + c._cantidadDeEmpleados + " " + c._comerciante + " " + c._precioAlquiler;
        }

        public static bool operator ==(Comercio a, Comercio b)
        {
            bool respuesta = false;

            if(a._nombre == b._nombre)
            {
                if(a._comerciante==b._comerciante)
                {
                    respuesta = true;
                }
            }

            return respuesta;
        }

        public static bool operator !=(Comercio a, Comercio b)
        {
            return !(a == b);
        }
    }
}
