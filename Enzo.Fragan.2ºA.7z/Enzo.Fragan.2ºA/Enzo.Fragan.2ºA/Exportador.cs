﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{  
    public class Exportador : Comercio
    {
        public ETipoProducto tipo;

        public Exportador(string nombreComercio,float precioAlquiler, string nombre, string apellido, ETipoProducto tipo) : base(precioAlquiler,nombreComercio,nombre,apellido)
        {
            this.tipo = tipo;
        }

        public string Mostrar()
        {
            
        }
    }
}
